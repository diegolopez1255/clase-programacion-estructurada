
from usuarios.usuario import menu_inicio_sesion

def main():
    menu_inicio_sesion()

if __name__ == "__main__":
    main()
